package b;

import java.sql.SQLException;

import da.UserDA;

public class UserB {
	private UserDA userDA;
	public UserB() {
		userDA = new UserDA();
	}
	public boolean checkUser(String userName, String password) throws SQLException {
		return userDA.checkUser(userName, password);
	}
}
