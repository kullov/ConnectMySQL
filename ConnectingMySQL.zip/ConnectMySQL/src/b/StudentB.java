package b;

import java.sql.SQLException;
import java.util.List;

import javax.swing.table.DefaultTableModel;

import da.StudentDA;
import e.Student;

public class StudentB {
	private StudentDA studentDA;

	public StudentB() {
		studentDA = new StudentDA();
	}

	public DefaultTableModel getAllStudents() throws SQLException {
		DefaultTableModel model = new DefaultTableModel();
		List<Student> students = studentDA.getAll();
		String[] cells;

		model.addColumn("ID");
		model.addColumn("Name");
		model.addColumn("Age");
		model.addColumn("Gender");
		model.addColumn("Class");
		model.addColumn("Hometown");

		for (Student student : students) {
			cells = new String[6];
			cells[0] = String.valueOf(student.getId());
			cells[1] = student.getName();
			cells[2] = String.valueOf(student.getDob());
			cells[3] = student.getGender();
			cells[4] = student.getClassName();
			cells[5] = student.getHomeTown();

			model.addRow(cells);
		}
		return model;
	}

	public void addStudent(String name, String dob, String gender, String className, String homeTown)
			throws SQLException {
		int age = Integer.parseInt(dob);
		studentDA.addStudent(name, age, gender, className, homeTown);
	}

	public void editStudent(String id, String name, String dob, String gender, String className, String homeTown)
			throws SQLException {
		studentDA.editStudent(Integer.parseInt(id), name, Integer.parseInt(dob), gender, className, homeTown);
	}

	public void deleteStudent(String id) throws SQLException {
		studentDA.deleteStudent(Integer.parseInt(id));
	}
}
