package p;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import b.StudentB;
import b.UserB;

import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;

public class MainFrame extends JFrame {

	private JPanel contentPane;
	private StudentB studentB;
	private DefaultTableModel model;
	private JTable tblStudent;
	private UserB userB;
	private JButton btnRefresh;
	private JButton btnAdd;
	private JButton btnDelete;
	private JButton btnEdit;
	private JButton btnExit;
	private JMenuItem mntmLogout;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrame frame = new MainFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public void initModel() throws SQLException {
		model = studentB.getAllStudents();
		tblStudent.setModel(model);
	}

	public void login(String userName, String password) throws SQLException {
		if (userB.checkUser(userName, password) == true) {
			tblStudent.setEnabled(true);
			btnRefresh.setEnabled(true);
			btnAdd.setEnabled(true);
			btnDelete.setEnabled(true);
			btnEdit.setEnabled(true);
		} else {
			JOptionPane.showMessageDialog(null, "Login again!");
		}
	}

	public MainFrame() {
		studentB = new StudentB();
		userB = new UserB();

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);

		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		JMenu mnUser = new JMenu("User");
		menuBar.add(mnUser);

		JMenuItem mntmLogin = new JMenuItem("Login");
		mntmLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				LoginFrame loginFrame = new LoginFrame(MainFrame.this);
				loginFrame.setVisible(true);
				String userName = loginFrame.getTxtUserName().getText();
				String password = loginFrame.getTxtPassword().getText();

				try {
					login(userName, password);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		mnUser.add(mntmLogin);

		mntmLogout = new JMenuItem("Logout");
		mntmLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tblStudent.setEnabled(false);
				btnRefresh.setEnabled(false);
				btnAdd.setEnabled(false);
				btnDelete.setEnabled(false);
				btnEdit.setEnabled(false);
				JOptionPane.showMessageDialog(null, "OK!");
			}
		});
		mnUser.add(mntmLogout);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

		JScrollPane scrollPane = new JScrollPane();
		contentPane.add(scrollPane, BorderLayout.CENTER);

		tblStudent = new JTable();
		scrollPane.setViewportView(tblStudent);
		try {
			initModel();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.SOUTH);

		btnRefresh = new JButton("Refresh");
		btnRefresh.setEnabled(false);
		btnRefresh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					initModel();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		panel.add(btnRefresh);

		btnAdd = new JButton("Add");
		btnAdd.setEnabled(false);
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddFrame addFrame = new AddFrame(MainFrame.this);
				addFrame.setVisible(true);
				try {
					String name = addFrame.textFieldName.getText();
					String age = addFrame.textFieldAge.getText();
					String gender = addFrame.textFieldGender.getText();
					String className = addFrame.textFieldClass.getText();
					String homeTown = addFrame.textFieldHomeTown.getText();
					studentB.addStudent(name, age, gender, className, homeTown);
					initModel();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
		panel.add(btnAdd);

		btnDelete = new JButton("Delete");
		btnDelete.setEnabled(false);
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (tblStudent.getSelectedRow() < 0) {
					JOptionPane.showMessageDialog(null, "Choose 1 id of student!");
				} else {
					try {
						String id = (String) tblStudent.getValueAt(tblStudent.getSelectedRow(), 0);
						studentB.deleteStudent(id);
						initModel();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});

		panel.add(btnDelete);

		btnEdit = new JButton("Edit");
		btnEdit.setEnabled(false);
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (tblStudent.getSelectedRow() < 0) {
					JOptionPane.showMessageDialog(null, "Choose 1 id of student!");
				} else {
					AddFrame editFrame = new AddFrame(MainFrame.this);

					editFrame.textFieldName.setText((String) tblStudent.getValueAt(tblStudent.getSelectedRow(), 1));
					editFrame.textFieldAge.setText((String) tblStudent.getValueAt(tblStudent.getSelectedRow(), 2));
					editFrame.textFieldGender.setText((String) tblStudent.getValueAt(tblStudent.getSelectedRow(), 3));
					editFrame.textFieldClass.setText((String) tblStudent.getValueAt(tblStudent.getSelectedRow(), 4));
					editFrame.textFieldHomeTown.setText((String) tblStudent.getValueAt(tblStudent.getSelectedRow(), 5));

					editFrame.setVisible(true);
					try {
						String id = (String) tblStudent.getValueAt(tblStudent.getSelectedRow(), 0);
						String name = editFrame.textFieldName.getText();
						String dob = editFrame.textFieldAge.getText();
						String gender = editFrame.textFieldGender.getText();
						String className = editFrame.textFieldClass.getText();
						String homeTown = editFrame.textFieldHomeTown.getText();
						studentB.editStudent(id, name, dob, gender, className, homeTown);
						initModel();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		});
		panel.add(btnEdit);

		btnExit = new JButton("Exit");
		btnExit.setEnabled(true);
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		panel.add(btnExit);
	}

}
