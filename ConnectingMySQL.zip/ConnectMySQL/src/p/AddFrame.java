package p;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import net.miginfocom.swing.MigLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JDialog;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AddFrame extends JDialog {

	private JPanel contentPane;
	public JTextField textFieldAge;
	public JTextField textFieldClass;
	public JTextField textFieldHomeTown;
	private JButton btnOK;
	private JButton btnCancel;
	public JTextField textFieldName;
	private JLabel lblGender;
	public JTextField textFieldGender;

	public AddFrame(JFrame parent) {
		super(parent, "", true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new MigLayout("", "[][grow]", "[][][][][][]"));

		JLabel lblName = new JLabel("Name");
		contentPane.add(lblName, "cell 0 0,alignx trailing");

		textFieldName = new JTextField();
		contentPane.add(textFieldName, "cell 1 0,growx");
		textFieldName.setColumns(10);

		JLabel lblAge = new JLabel("Age");
		contentPane.add(lblAge, "cell 0 1,alignx trailing");

		textFieldAge = new JTextField();
		contentPane.add(textFieldAge, "cell 1 1,growx");
		textFieldAge.setColumns(10);

		btnOK = new JButton("OK");
		btnOK.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				dispose();
			}
		});

		lblGender = new JLabel("Gender");
		contentPane.add(lblGender, "cell 0 2,alignx trailing");

		textFieldGender = new JTextField();
		contentPane.add(textFieldGender, "cell 1 2,growx");
		textFieldGender.setColumns(10);

		JLabel lblClass = new JLabel("Class");
		contentPane.add(lblClass, "cell 0 3,alignx trailing");

		textFieldClass = new JTextField();
		contentPane.add(textFieldClass, "cell 1 3,growx");
		textFieldClass.setColumns(10);

		JLabel lblHometown = new JLabel("Hometown");
		contentPane.add(lblHometown, "cell 0 4,alignx trailing");

		textFieldHomeTown = new JTextField();
		contentPane.add(textFieldHomeTown, "cell 1 4,growx");
		textFieldHomeTown.setColumns(10);
		contentPane.add(btnOK, "flowx,cell 1 5");

		btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		contentPane.add(btnCancel, "cell 1 5");
	}

	public JTextField getTextFieldAge() {
		return textFieldAge;
	}

	public void setTextFieldAge(JTextField textFieldAge) {
		this.textFieldAge = textFieldAge;
	}

	public JTextField getTextFieldClass() {
		return textFieldClass;
	}

	public void setTextFieldClass(JTextField textFieldClass) {
		this.textFieldClass = textFieldClass;
	}

	public JTextField getTextFieldHomeTown() {
		return textFieldHomeTown;
	}

	public void setTextFieldHomeTown(JTextField textFieldHomeTown) {
		this.textFieldHomeTown = textFieldHomeTown;
	}

	public JButton getBtnAdd() {
		return btnOK;
	}

	public void setBtnAdd(JButton btnAdd) {
		this.btnOK = btnAdd;
	}

	public JButton getBtnCancel() {
		return btnCancel;
	}

	public void setBtnCancel(JButton btnCancel) {
		this.btnCancel = btnCancel;
	}

	public JTextField getTextFieldName() {
		return textFieldName;
	}

	public void setTextFieldName(JTextField textFieldName) {
		this.textFieldName = textFieldName;
	}

	public JTextField getTextFieldGender() {
		return textFieldGender;
	}

	public void setTextFieldGender(JTextField textFieldGender) {
		this.textFieldGender = textFieldGender;
	}

}
