package da;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import e.Student;

public class StudentDA {
	private Connection connection;
	public StudentDA() {
		try {
			connection = MyConnection.getConnection();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public List<Student> getAll() throws SQLException{
		List<Student> students = new ArrayList<Student>();
		Student student;
		Statement stmt = connection.createStatement();
		String sql = "SELECT * FROM Students";
		ResultSet rs = stmt.executeQuery(sql);
		while (rs.next()) {
			student = new Student(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getString(4), rs.getString(5), rs.getString(6));
			students.add(student);
		}
		
		return students;	
	}
	public void deleteStudent(int id) throws SQLException{
		PreparedStatement stmt;
		String sql;
		sql = "DELETE FROM Students WHERE students.id = ?";
		stmt = connection.prepareStatement(sql);
		stmt.setInt(1, id);
		stmt.executeUpdate();
	}
	public void editStudent(int id, String name, int dob, String gender, String className, String homeTown) throws SQLException {
		String sql;
		PreparedStatement stmt;
		sql = "UPDATE Students SET name = ?, age = ?, gender = ?, class = ?, hometown = ? WHERE id = ?";
		stmt = connection.prepareStatement(sql);
		stmt.setString(1, name);
		stmt.setInt(2, dob);
		stmt.setString(3, gender);
		stmt.setString(4, className);
		stmt.setString(5, homeTown);
		stmt.setInt(6, id);
		stmt.executeUpdate();
	}
	public void addStudent(String name, int dob, String gender, String className, String homeTown) throws SQLException {
		String sql = "INSERT INTO Students(id, name, age, gender, class, hometown) VALUES (NULL, ?, ?, ?, ?, ?);";
		PreparedStatement stmt = connection.prepareStatement(sql);
		stmt.setString(1, name);
		stmt.setInt(2, dob);
		stmt.setString(3, gender);
		stmt.setString(4, className);
		stmt.setString(5, homeTown);
		stmt.executeUpdate();
	}
}
