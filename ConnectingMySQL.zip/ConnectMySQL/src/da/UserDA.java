package da;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDA {
	private Connection connection;

	public UserDA() {
		try {
			connection = MyConnection.getConnection();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public boolean checkUser(String userName, String password) throws SQLException {
		String sql = "SELECT * FROM login WHERE username = ? AND password = ?";
		PreparedStatement stmt = connection.prepareStatement(sql);
		ResultSet rs;
		stmt.setString(1, userName);
		stmt.setString(2, password);
		rs = stmt.executeQuery();
		return rs.next();
	}
}
