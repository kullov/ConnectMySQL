package e;

public class Student {
	private int id;
	private String name;
	private int dob;
	private String gender;
	private String className;
	private String homeTown;
	public Student() {
		super();
	}
	public Student(int id, String name, int dob, String gender, String className, String homeTown) {
		super();
		this.name = name;
		this.id = id;
		this.dob = dob;
		this.gender = gender;
		this.className = className;
		this.homeTown = homeTown;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getDob() {
		return dob;
	}
	public void setDob(int dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getHomeTown() {
		return homeTown;
	}
	public void setHomeTown(String homeTown) {
		this.homeTown = homeTown;
	}
	
}
